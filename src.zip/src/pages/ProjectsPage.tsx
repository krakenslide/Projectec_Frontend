import { useEffect, useMemo, useState } from "react";
import {
  Download,
  FolderKanban,
  Loader2,
  Plus,
  Search,
  X,
  ChevronRight,
} from "lucide-react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { getErrorMessage } from "../api/client";
import { createProject, listProjects } from "../api/projects";
import { downloadDailySummaryExcel } from "../api/analytics";
import type { Project } from "../types/project";
import { useToast } from "../components/ui/Toast";
import WorkOrbitLoader from "../components/ui/WorkOrbitLoader";

export default function ProjectsPage() {
  const { organizationId } = useParams<{ organizationId: string }>();
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [projects, setProjects] = useState<Project[]>([]);
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [description, setDescription] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [exporting, setExporting] = useState(false);

  const load = async () => {
    if (!organizationId) return;
    setLoading(true);
    setError("");
    try {
      setProjects(await listProjects(organizationId));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    void load();
  }, [organizationId]);
  const filteredProjects = useMemo(() => {
    const term = query.trim().toLowerCase();
    return term
      ? projects.filter((project) =>
          `${project.name} ${project.code} ${project.description ?? ""}`
            .toLowerCase()
            .includes(term),
        )
      : projects;
  }, [projects, query]);
  const exportDailySummary = async () => {
    if (!organizationId || exporting) return;
    setExporting(true);
    setError("");
    try {
      const filename = await downloadDailySummaryExcel(organizationId);
      showToast(`Downloaded ${filename}`);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setExporting(false);
    }
  };
  const openProject = (project: Project) => {
    localStorage.setItem("activeProjectId", project.id);
    localStorage.setItem("activeProjectName", project.name);
    navigate(`/organisations/${organizationId}/projects/${project.id}/tickets`);
  };
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!organizationId) return;
    setSaving(true);
    setError("");
    try {
      const project = await createProject(organizationId, {
        name: name.trim(),
        code: code.trim().toUpperCase(),
        description: description.trim(),
      });
      showToast("Project created");
      openProject(project);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };
  if (!organizationId)
    return <p className="text-red-300">Choose an organisation first.</p>;

  return (
    <div className="pj-app-page pj-projects-page space-y-10 font-['Inter',ui-sans-serif,sans-serif">
      <header className="pj-page-hero border-b border-zinc-200 pb-9 dark:border-zinc-800">
        <div>
          <Link className="pj-dashboard-link" to="/organisations">
            ← Organisations
          </Link>
          <p className="pj-dashboard-eyebrow mt-6">
            02 — Organisation / Projects
          </p>
          <h1 className="mt-3 font-['Instrument_Serif',Georgia,serif] text-6xl leading-[.92] text-zinc-900 dark:text-white">
            What are we building?
          </h1>
          <p className="mt-5 max-w-xl text-sm leading-6 text-zinc-600 dark:text-zinc-400">
            Your project portfolio, focused on the work the organisation has
            chosen to pursue.
          </p>
        </div>
        <div className="mt-7 flex flex-wrap gap-2">
          <button
            className="pj-outline-action"
            disabled={exporting}
            onClick={() => void exportDailySummary()}
            type="button"
          >
            {exporting ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Download className="h-4 w-4" />
            )}
            {exporting ? "Preparing…" : "Export daily summary"}
          </button>
          <button
            className="pj-hard-action inline-flex min-h-11 items-center gap-2 bg-zinc-950 px-5 text-[11px] uppercase tracking-[.18em] text-white transition-transform hover:-translate-y-0.5 dark:bg-[#f5f3ee] dark:text-zinc-950"
            onClick={() => setShowForm((value) => !value)}
            type="button"
          >
            {showForm ? (
              <X className="h-4 w-4" />
            ) : (
              <Plus className="h-4 w-4" />
            )}
            {showForm ? "Close" : "New project"}
          </button>
        </div>
      </header>
      {showForm && (
        <form className="pj-form-surface" onSubmit={submit}>
          <div className="mb-6">
            <p className="pj-dashboard-eyebrow">Create</p>
            <h2 className="mt-2 font-['Instrument_Serif',Georgia,serif] text-3xl text-zinc-900 dark:text-white">
              Start a new project.
            </h2>
          </div>
          <div className="grid gap-5 md:grid-cols-2">
            <label className="pj-field">
              <span>Project name</span>
              <input
                minLength={3}
                onChange={(e) => setName(e.target.value)}
                placeholder="Network Automation"
                required
                value={name}
              />
            </label>
            <label className="pj-field">
              <span>Code</span>
              <input
                maxLength={10}
                minLength={3}
                onChange={(e) => setCode(e.target.value)}
                placeholder="NET"
                required
                value={code}
              />
            </label>
            <label className="pj-field md:col-span-2">
              <span>Outcome</span>
              <textarea
                maxLength={500}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="What outcome should this project deliver?"
                value={description}
              />
            </label>
          </div>
          <button
            className="pj-outline-action mt-6"
            disabled={saving}
            type="submit"
          >
            {saving ? "Creating…" : "Create project"}
          </button>
        </form>
      )}
      {error && (
        <p className="border-y border-red-500 py-3 text-sm text-red-500 dark:text-red-300">
          {error}
        </p>
      )}
      {!loading && projects.length > 0 && (
        <div className="flex items-center justify-between gap-4 border-b border-zinc-200 pb-4 dark:border-zinc-800">
          <div className="relative max-w-md flex-1">
            <Search className="pointer-events-none absolute left-0 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-600 dark:text-zinc-300" />
            <input
              className="w-full border-b border-zinc-300 bg-transparent py-2 pl-6 text-sm text-zinc-900 outline-none transition-colors placeholder:text-zinc-500 focus:border-zinc-900 dark:border-zinc-700 dark:text-white dark:placeholder:text-zinc-400 dark:focus:border-white"
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search projects"
              value={query}
            />
          </div>
          <span className="shrink-0 font-mono text-[10px] uppercase tracking-[.14em] text-zinc-600 dark:text-zinc-300">
            {filteredProjects.length} shown
          </span>
        </div>
      )}
      {loading ? (
        <WorkOrbitLoader />
      ) : projects.length ? (
        filteredProjects.length ? (
          <section className="divide-y divide-zinc-200 dark:divide-zinc-800">
            {filteredProjects.map((project, index) => (
              <button
                className="pj-project-row group w-full py-8 text-left"
                key={project.id}
                onClick={() => openProject(project)}
                type="button"
              >
                <div className="grid gap-7 md:grid-cols-[56px_minmax(0,1fr)_24px] md:items-center">
                  <span className="font-mono text-[10px] tracking-[.14em] text-zinc-400">
                    {String(index + 1).padStart(2, "0")}
                  </span>
                  <div className="min-w-0">
                    <span className="font-mono text-[10px] tracking-[.16em] text-zinc-500">
                      {project.code}
                    </span>
                    <h2 className="mt-3 font-['Instrument_Serif',Georgia,serif] text-4xl leading-none text-zinc-900 dark:text-white">
                      {project.name}
                    </h2>
                    <p className="mt-3 max-w-2xl text-sm leading-6 text-zinc-500 dark:text-zinc-400">
                      {project.description ||
                        "No project outcome has been defined yet."}
                    </p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-zinc-400 transition-all group-hover:translate-x-1 group-hover:text-pj-lime" />
                </div>
              </button>
            ))}
          </section>
        ) : (
          <div className="pj-empty-state border-y border-[var(--pj-border)] px-6 py-16 text-center">
            <Search className="mx-auto mb-4 h-6 w-6 text-zinc-400" />
            <p className="pj-dashboard-eyebrow">No match</p>
            <h2 className="mt-2 font-['Instrument_Serif',Georgia,serif] text-3xl text-zinc-900 dark:text-white">
              Nothing fits this search.
            </h2>
            <p className="mt-2 text-sm text-zinc-500 dark:text-zinc-400">
              Try another project name or code.
            </p>
          </div>
        )
      ) : (
        <div className="pj-empty-state border-y border-[var(--pj-border)] px-6 py-16 text-center">
          <FolderKanban className="mx-auto mb-5 h-7 w-7 text-zinc-400" />
          <p className="pj-dashboard-eyebrow">No projects yet</p>
          <h2 className="mt-2 font-['Instrument_Serif',Georgia,serif] text-3xl text-zinc-900 dark:text-white">
            Start with an outcome.
          </h2>
          <p className="mx-auto mt-3 max-w-md text-sm text-zinc-500 dark:text-zinc-400">
            Create a project and give the team a clear place to move work
            forward.
          </p>
        </div>
      )}
    </div>
  );
}
